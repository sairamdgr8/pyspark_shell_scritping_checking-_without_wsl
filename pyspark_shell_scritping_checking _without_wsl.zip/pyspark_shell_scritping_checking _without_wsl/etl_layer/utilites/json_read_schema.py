import json
import os
import argparse
parser = argparse.ArgumentParser()
parser.add_argument('--metaConfigFilename', type=str, required=True)
args = parser.parse_args()

print(os.curdir)
print(os.listdir())


class Json_read_schema:

    def meta_schema_read(self: dict) -> dict:
        """
        this method is to check the source path of the code.
        """
        with open(args.metaConfigFilename) as f:
            f_data = json.load(f)

            return(f_data)
