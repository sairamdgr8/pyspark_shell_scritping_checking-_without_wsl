from pyspark.sql import DataFrame,column



class data_transformations():
    def Xermations_sorting(self,*col:column,dataframe:DataFrame) -> DataFrame:
        """
        this method helps to sort the data based on columns provided

        :param col:
        :param dataframe:
        :return:
        """
        df=dataframe.sort(*col,ascending = [True])
        return df

    def single_row_dataframe(self,dataframe_list:DataFrame) -> list:
        df = dataframe_list.take(1)
        return df






