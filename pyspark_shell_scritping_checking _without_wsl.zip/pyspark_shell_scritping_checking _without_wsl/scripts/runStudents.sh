#!/bin/bash
#source_home="C://Users//Hp X360//Python_Spark//pyspark_shell_scritping_checking"

#SPARK_HOME="/opt/spark"
#SPARK_HOME="C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking"
#SPARK_HOME="C:/Bigdata/Spark3x"
#SPARK_HOME="C:/Users/Hp X360/python_spark/pyspark_shell_scritping_checking/venv/lib/site-packages/pyspark"
#SPARK_HOME="C:/Bigdata/Spark3x"
#export SPARK_HOME
#export PATH=$SPARK_HOME/bin:$PATH
#if [ ! -d /home/mlzboy/b2c2/shared/db ]; then
#  mkdir -p /home/mlzboy/b2c2/shared/db;
#fi
#export SPARK_HOME="C:/Users/Hp X360/python_spark/pyspark_shell_scritping_checking/venv/Scripts/"
#export SPARK_HOME="C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking"
#export SPARK_HOME="C:/Bigdata/Spark3x"


#export PATH=$PATH:${SPARK_HOME}/bin

#SPARK_HOME="mnt/c/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/venv/Scripts"
#PYTHONPATH ="C:/Bigdata/Spark3x/python/lib/py4j-0.10.9.5-src.zip"
#SPARK_HOME="C:/Users/Hp X360/python_spark/pyspark_shell_scritping_checking/venv/lib/site-packages/pyspark"
#PYSPARK_APP="C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/etl_main.py"
#CONFIG_LOC="C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/metadata/students_etl_schema.json"
#echo "SPARK_HOME: $SPARK_HOME"
#echo "PYSPARK_APP: $PYSPARK_APP"
#echo "CONFIG_LOC: $CONFIG_LOC"

#export SPARK_HOME="C:/Bigdata/Spark3x"
#export PATH=$PATH:${SPARK_HOME}/bin




#set SPARK_HOME="C:/Bigdata/Spark3x"
#set HADOOP_HOME=%SPARK_HOME%
#set PYTHONPATH=%SPARK_HOME%/python;%SPARK_HOME%/python/lib/py4j-0.10.9.5-src.zip;%PYTHONPATH%

#"$SPARK_HOME"/bin/spark-submit "$PYSPARK_APP" metaConfigFilename="$CONFIG_LOC"

#$SPARK_HOME/spark-submit "C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/etl_main.py" --metaConfigFilename="C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/metadata/students_etl_schema.json"

#spark-submit "C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/src_layer/src_main.py" --metaConfigFilename="C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/src_layer/metadata/students_schema.json"

spark-submit "/mnt/c/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/src_layer/src_main.py" --metaConfigFilename="/mnt/c/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/src_layer/metadata/students_schema.json"



#$SPARK_HOME/spark-submit "C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/etl_main.py" --metaConfigFilename="C:/Users/Hp X360/Python_Spark/pyspark_shell_scritping_checking/etl_layer/metadata/students_etl_schema.json"

#spark-submit etl_layer/etl_main.py --metaConfigFilename=etl_layer//metadata//students_etl_schema.json

#"$SPARK_HOME"/spark-submit etl_layer/etl_main.py --metaConfigFilename=etl_layer//metadata//students_etl_schema.json

status=$?
if [ $status -ne 0 ]
then
   echo "src_layer Students job failed"
   exit 1
fi