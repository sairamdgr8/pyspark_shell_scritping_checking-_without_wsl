# -*- coding: utf-8 -*-
"""
Created on Tue Sep 19 18:03:58 2023

@author: SAI
"""

#from pyspark.sql import SparkSession
#import pyspark.sql.functions as f
#import pyspark.sql.types as t




#### loading source metadata


import json
with open("metadata/students_schema.json") as f:
    f_data=json.load(f)

#f_data=json.loads(f.text)
#print(f_data["source_input_path"])
# for i in f_data:
#     pass
#     #print(i)
#     print(f_data[i])
#     f.close()


print(f_data)

#with open('resultJSON.txt') as f:
#    json_data = json.load(f)

#print(f_data['students_schema'])











